# aws-nodejs-sample-codebuild
From the BackSpace Academy AWS Certified Associate (4 Cert Pack + Practice Exams) course.
Sample NodeJS code for the hands-on CI/CD lab of the Deployment section.
